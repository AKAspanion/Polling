package learning.spanion.com.polling;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Window;
import android.view.WindowManager;

/**
 * Created by Ankit Kumar on 7/11/2017.
 */

public class Splash extends Activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
        Thread splashTimer = new Thread(){
            public void run(){
                try{
                    sleep(2000);
                }catch (Exception e){
                    e.printStackTrace();
                }
                finally {
                    Intent openLoginPage = new Intent("learning.spanion.com.polling.FRONTPAGE");
                    startActivity(openLoginPage);
                }
            }
        };
        splashTimer.start();
    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
